﻿using Employee.Models;
using Employee.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Business
{
    public interface IEmployeeServices
    {
        Task<IEnumerable<EmployeeModel>> GetAll(string department);

    }
    public class EmployeeServices : IEmployeeServices
    {
        IEmployeeRepository _employeeRepository;
        public EmployeeServices(IEmployeeRepository employeeRepository)
        {
            this._employeeRepository = employeeRepository;
            
        }
        public async Task<IEnumerable<EmployeeModel>> GetAll(string department)
        {
            
          return await _employeeRepository.GetListEmployees(department);
        }
    }
}
