﻿using Employee.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Repository
{
    public class EmployeeRepository : DBRepository, IEmployeeRepository
    {
        public async Task<IEnumerable<EmployeeModel>> GetListEmployees(string department)
        {
            try
            {
                if(department  !=null)
                {
                    var list = await Database.GetCollection<EmployeeModel>("employees")
                    .Find(x => x.Department == department)
                    .ToListAsync();
                    return list;
                }
                else
                {
                    var list = await Database.GetCollection<EmployeeModel>("employees")
                     .Find(x =>x.Department.Length>0)              
                     .ToListAsync();
                        return list;
                }
            }
            catch(Exception ex)
            {
                return null;
            }
        }
    }
}
