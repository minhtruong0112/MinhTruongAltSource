﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;
namespace Employee.Repository
{
    public interface IEmployeeRepository: IDisposable
    {
        Task <IEnumerable<EmployeeModel>> GetListEmployees(string department);
    }
}
