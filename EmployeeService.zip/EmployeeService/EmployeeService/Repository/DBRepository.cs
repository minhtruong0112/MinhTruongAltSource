﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;
using Microsoft.Extensions.Configuration;
namespace Employee.Repository
{
    public class DBRepository : IDisposable
    {        
        public DBRepository()
            
        {            
            string key1 = "mongodb+srv://demo:INGhTrainQuAlDetOrPt@cluster0-mws5t.mongodb.net?retryWrites=true"; 
            string key2 = "majority"; 
            string key3 = "vr"; 

            var connectString=  key1 + "&w=" + key2;
            _client = new MongoClient(connectString);
            _database = _client.GetDatabase(key3);
        }

       
        public void Dispose()
        {
            _client = null;
            _database = null;
        }

        public string DatabaseName { get; set; }
        private IMongoClient _client;
        private IMongoDatabase _database;

        public IMongoDatabase Database
        {
            get
            {
                return _database;
            }
        }
    }
}