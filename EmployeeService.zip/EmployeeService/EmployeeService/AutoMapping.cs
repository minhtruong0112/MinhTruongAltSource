﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Employee.Models;

namespace EmployeeService
{
    public class AutoMapping:Profile
    {
        public AutoMapping()
        {
            CreateMap<EmployeeModel, EmployeeModelDTO>();
        }
    }
}
