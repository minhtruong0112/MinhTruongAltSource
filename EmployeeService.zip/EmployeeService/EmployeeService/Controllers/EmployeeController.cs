﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Employee.Models;
using Employee.Business;
using Microsoft.AspNetCore.Authorization;
using AutoMapper;

namespace Employee.Controllers
{
    [ApiController]
    [Route("[controller]")]    
    public class EmployeeController : ControllerBase
    {
        private IEmployeeServices _employeeService;
        private readonly IMapper _mapper;
        

        private readonly ILogger<EmployeeController> _logger;

        public EmployeeController(IEmployeeServices employeeService,
            IMapper mapper,
            ILogger<EmployeeController> logger)
        {
            _employeeService = employeeService;
            _mapper = mapper;
            _logger = logger;
        }

        [HttpGet]
        public  List<EmployeeModelDTO> Get(string department = null)
        {            
            IEnumerable<EmployeeModel> employees = _employeeService.GetAll(department).Result;
            var listEmployee = _mapper.Map<List<EmployeeModel>, List<EmployeeModelDTO>>(employees.ToList());            
            return listEmployee;
        }
    }
}
