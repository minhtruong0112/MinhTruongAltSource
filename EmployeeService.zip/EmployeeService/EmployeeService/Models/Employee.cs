﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Employee.Models
{
    public class EmployeeModel
    {

        
        public ObjectId _id { get; set; }
        public string Employee_No { get; set; }
        public string Employee_FName { get; set; }
        public string Employee_LName { get; set; }
        public string Department { get; set; }
    }
    public class EmployeeModelDTO
    {
        public string Employee_No { get; set; }
        public string Employee_FName { get; set; }
        public string Employee_LName { get; set; }
        public string Department { get; set; }
    }
}
